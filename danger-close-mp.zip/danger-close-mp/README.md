# Danger Close Shelter – Multiplayer

This package turns the single-player GitHub Pages game into a real multiplayer experience your friends can join.

## What you get

- `server.js` – Socket.io relay (rooms, presence, host election)
- `Danger-Close-MP.html` – ready-to-upload game client
- Drop-in lobby field for the server URL

## 1. Deploy the server (one-time)

GitHub Pages is static, so the realtime server must live somewhere else.

### Easiest free options

**Render.com**
1. Create a free account → New → Web Service
2. Connect a repo that contains this `server.js` + `package.json`, **or** use the “Deploy from public Git repo” flow after you push these files somewhere.
3. Build command: `npm install`
4. Start command: `npm start`
5. After deploy you get a URL like `https://danger-close-xxxx.onrender.com`

**Railway.app**
1. New Project → Deploy from GitHub (or empty + upload)
2. Add the two files, set start command `npm start`
3. Railway gives you an HTTPS URL automatically

**Local + ngrok** (quick tests only)
```bash
npm install && npm start
ngrok http 3000
```

## 2. Put the game on your site

Your live site is: https://christheman666638.github.io/SKimmy/

Repo: https://github.com/christheman666638/SKimmy

1. Download `Danger-Close-MP.html` from this folder
2. Rename it to `index.html`
3. In the GitHub repo, replace the existing `index.html` with this new file (upload via the web UI or git push)
4. Wait ~30 seconds for GitHub Pages to update

## 3. Play with friends

1. Open https://christheman666638.github.io/SKimmy/
2. Click **Squad play**
3. Enter a callsign
4. Paste your server URL in the **Server URL** field (e.g. `https://danger-close-xxxx.onrender.com`)
5. Click **Create squad** → share the 5-character code
6. Friends open the same page, enter the same Server URL + the code, then **Join**
7. Everyone hits **Ready**, host clicks **Launch**

The Server URL is saved in localStorage so you only have to type it once.

## Notes

- Max 8 players per squad
- Host is the earliest player in the lobby (controls the gunship)
- Solo play still works with zero setup
- The server must be HTTPS if the game is served over HTTPS (all free hosts above do this)

## Files

| File | Use |
|------|-----|
| `server.js` | Run on Render / Railway / your VPS |
| `package.json` | Dependencies for the server |
| `Danger-Close-MP.html` | Upload as `index.html` to the GitHub repo |
| `client-adapter.js` | Optional reference if you want to patch the original yourself |
